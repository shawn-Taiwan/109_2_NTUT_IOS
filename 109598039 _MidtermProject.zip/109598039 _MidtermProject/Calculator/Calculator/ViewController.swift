//
//  ViewController.swift
//  Calculator
//
//  Created by Shawn on 2021/3/8.
//

import UIKit

class ViewController: UIViewController {
    var dot:Bool = false
    var flag: Bool = false
    var lastsum: Double = 0.0
    var calculat:Calculat = Calculat()
    @IBOutlet weak var all: UILabel!
    @IBOutlet weak var sum: UITextField!
    @IBAction func zero(_ sender: Any) {
        if(sum.text=="0" || sum.text==""){
            sum.text = "0"
        }
        else{
            sum.text = sum.text! + "0"
            all.text = all.text! + "0"}
    }
    @IBAction func one(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "1"
            all.text =  "1"
            flag=false
        }
        else{
            sum.text = sum.text! + "1"
            all.text = all.text! + "1"}
    }
    
    @IBAction func two(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "2"
            all.text = "2"
            flag=false
        }
        else{
            sum.text = sum.text! + "2"
            all.text = all.text! + "2"}
    }
    
    @IBAction func three(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "3"
            all.text = "3"
            flag=false
        }
        else{
            sum.text = sum.text! + "3"
            all.text = all.text! + "3"}
    }
    
    @IBAction func four(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "4"
            all.text = "4"
            flag=false
        }
        else{
            sum.text = sum.text! + "4"
            all.text = all.text! + "4"}
    }
    
    @IBAction func five(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "5"
            all.text = "5"
            flag=false
        }else{
            sum.text = sum.text! + "5"
            all.text = all.text! + "5"}
    }
    
    @IBAction func six(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "6"
            all.text = "6"
            flag=false
        }
        else{
            sum.text = sum.text! + "6"
            all.text = all.text! + "6"}
    }
    
    @IBAction func seven(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "7"
            all.text = "7"
            flag=false
        }
        else{
            sum.text = sum.text! + "7"
            all.text = all.text! + "7"}
    }
    
    @IBAction func eight(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "8"
            all.text = "8"
            flag=false
        }
        else{
            sum.text = sum.text! + "8"
            all.text = all.text! + "8"}
    }
    
    @IBAction func nine(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "9"
            all.text = "9"
            flag=false
        }
        else{
            sum.text = sum.text! + "9"
            all.text = all.text! + "9"}
    }
    @IBAction func Add(_ sender: Any) {
        if(sum.text==""){
            all.text!.removeLast()
            calculat.signitemsRemoveLast()
            calculat.signitemsAdd(sign: "+")
            all.text = all.text! + "+"
        }
        else{
            
            
            calculat.numberitemsAdd(num:Double(sum.text!)!)
        
            calculat.signitemsAdd(sign: "+")
            if(sum.text=="0"){
                all.text = all.text! + "0"
                
            }
            var s = sum.text!.count
            for re in 1...s{
                all.text?.removeLast()
            }
            let new = calculat.resize(num:Double(sum.text!)!)
            all.text = all.text! + new
        sum.text = ""
            all.text = all.text! + "+"}
        flag = false
        dot = false
        
    }
    
    @IBAction func min(_ sender: Any) {
        if(sum.text==""){
            all.text!.removeLast()
            calculat.signitemsRemoveLast()
            calculat.signitemsAdd(sign: "-")
            all.text = all.text! + "-"
        }else{
            
            calculat.numberitemsAdd(num:Double(sum.text!)!)
            if(sum.text=="0"){
                all.text = all.text! + "0"
            }
            calculat.signitemsAdd(sign: "-")
        
            var s = sum.text!.count
            for re in 1...s{
                all.text?.removeLast()
            }
            let new = calculat.resize(num:Double(sum.text!)!)
            all.text = all.text! + new
            all.text = all.text! + "-"
            sum.text = ""
        }
        flag = false
        dot = false
    }
    
    @IBAction func multiply(_ sender: Any) {
        if(sum.text==""){
            all.text!.removeLast()
            calculat.signitemsRemoveLast()
            calculat.signitemsAdd(sign: "*")
            all.text = all.text! + "×"
        }else{
            
            calculat.numberitemsAdd(num:Double(sum.text!)!)
        
            calculat.signitemsAdd(sign:"*")
            if(sum.text=="0"){
                all.text = all.text! + "0"
            }
        
            var s = sum.text!.count
            for re in 1...s{
                all.text?.removeLast()
            }
            let new = calculat.resize(num:Double(sum.text!)!)
            all.text = all.text! + new
            all.text = all.text! + "×"
            sum.text = ""
        }
        flag = false
        dot = false
    }
    
    @IBAction func divis(_ sender: Any) {
        if(sum.text==""){
            all.text!.removeLast()
            calculat.signitemsRemoveLast()
            calculat.signitemsAdd(sign: "/")
            all.text = all.text! + "÷"
        }else{
            
            calculat.numberitemsAdd(num:Double(sum.text!)!)
            calculat.signitemsAdd(sign:"/")
            if(sum.text=="0"){
                all.text = all.text! + "0"
            }
        
            var s = sum.text!.count
            for re in 1...s{
                all.text?.removeLast()
            }
            let new = calculat.resize(num:Double(sum.text!)!)
            all.text = all.text! + new
            all.text = all.text! + "÷"
            sum.text = ""
        }
        flag = false
        dot = false
    }
    
    @IBAction func persent(_ sender: Any) {
        if(sum.text=="0" || flag == true){
        }
        else{
            
            var temp = calculat.persent(num: Double(sum.text!)!)
            
            sum.text = temp
            all.text = all.text! + "%"}
    }
    @IBAction func dot(_ sender: Any) {
        if(sum.text=="0" || flag == true){
            sum.text = "0."
            all.text = "0."
            flag=false
        }
        else{
            if(dot){
                
            }else{
                sum.text = sum.text! + "."
                all.text = all.text! + "."
                dot = true
            }}
    }
    @IBAction func eq(_ sender: Any) {
        if(sum.text=="0"){
            all.text = all.text! + "0"
        }

        var s = sum.text!.count
        for re in 1...s{
            print(s)
            print("a")
            all.text?.removeLast()
        }
        let new = calculat.resize(num:Double(sum.text!)!)
        all.text = all.text! + new
        calculat.numberitemsAdd(num: Double(sum.text!)!)
        sum.text = calculat.eq()
        all.text = all.text! + "="
        flag = true
        dot = false
        
    }
    
    @IBAction func MA(_ sender: Any) {
        all.text?.removeLast(sum.text!.count)
        all.text = all.text! + "±(" + sum.text! + ")"
        let value=calculat.changeSign(num:Double(sum.text!)!)
        sum.text = value
    }
    @IBAction func AC(_ sender: Any) {
        calculat.numberitemsRemoveAll()
        calculat.signitemsRemoveAll()
        sum.text = "0"
        all.text = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

