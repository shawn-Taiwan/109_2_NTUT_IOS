//
//  Calculat.swift
//  Calculator
//
//  Created by Shawn on 2021/5/3.
//

import Foundation

class Calculat{
    var signitems = [String]()
    var numberitems = [Double]()
    var last = [Double]()
    var flag: Bool = false
    var lastsum: Double = 0.0
    func numberitemsAdd(num:Double){
        numberitems.append(num)
    }
    
    func signitemsAdd(sign:String){
        signitems.append(sign)
    }
    func signitemsRemoveLast(){
        signitems.removeLast()
    }
    func signitemsRemoveAll(){
        signitems.removeAll()
    }
    func numberitemsRemoveAll(){
        signitems.removeAll()
    }
    func persent(num:Double) -> String {
         var num1 = num/100
        let formateter = NumberFormatter()
        formateter.minimumFractionDigits = 0
        formateter.maximumFractionDigits = 8
        let value = formateter.string(from: NSNumber(value: num1))
        return value!
    }
    func resize(num:Double) -> String {
        let formateter = NumberFormatter()
        formateter.minimumFractionDigits = 0
        formateter.maximumFractionDigits = 8
        let value = formateter.string(from: NSNumber(value: num))
        return value!
    }
    func changeSign(num:Double) -> String {
        var temp = num * -1
        let formateter = NumberFormatter()
        formateter.minimumFractionDigits = 0
        formateter.maximumFractionDigits = 8
        let value = formateter.string(from: NSNumber(value: temp))
        return value!
    }
    func eq()->String{
        var i = 0
        while i < signitems.count {
            if(i != 0){
                if(signitems[i-1] == "*" || signitems[i-1] == "/"){}
                else{last.append(numberitems[i])
                    
                }
            }else{
                last.append(numberitems[i])}
            if(signitems[i]=="*"){
                let temp = last.last! * numberitems[i+1]
                last.removeLast()
                last.append(temp)
            }
            if(signitems[i]=="/"){
                if(last.last! != 0 && numberitems[i+1] != 0){
                    let temp = last.last! / numberitems[i+1]
                    last.removeLast()
                    print(temp)
                    last.append(temp)}
                else{
                    last.removeLast()
                    last.append(0)
                }
            }
            if(signitems[i]=="-"){
                numberitems[i+1] = numberitems[i+1] * -1
            }
            i+=1
        }
        if(signitems.last == "+" || signitems.last == "-"){
            last.append(numberitems.last!)}
        i=0
        lastsum = 0
        print(last.count)
        while i<last.count {
            lastsum+=last[i]
            i+=1
            
        }
        let formateter = NumberFormatter()
        formateter.minimumFractionDigits = 0
        formateter.maximumFractionDigits = 8
        let value2 = formateter.string(from: NSNumber(value: lastsum))
        flag = true
        numberitems.removeAll()
        signitems.removeAll()
        last.removeAll()
        return value2!
    }
    
    
    
    init() {
    }
}
