//
//  ContentView.swift
//  Damo
//
//  Created by Shawn on 2021/5/3.
//

import SwiftUI

struct ContentView: View {
@State private var showSecondPage = false
    var body: some View {
        NavigationView{
            VStack{
                Image("move")
                NavigationLink(
                    destination: move(),
                    label: {
                       Text("電影介紹")
                })
                NavigationLink(
                    destination: actor(),
                    label: {
                       Text("演員")
                })
            }
            .navigationTitle("哥吉拉大戰金剛")
        }
        
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
