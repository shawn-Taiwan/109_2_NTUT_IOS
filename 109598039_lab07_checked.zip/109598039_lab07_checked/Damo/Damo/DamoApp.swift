//
//  DamoApp.swift
//  Damo
//
//  Created by Shawn on 2021/5/3.
//

import SwiftUI

@main
struct DamoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
