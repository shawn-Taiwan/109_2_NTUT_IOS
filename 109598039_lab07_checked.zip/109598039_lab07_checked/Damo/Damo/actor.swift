//
//  actor.swift
//  Damo
//
//  Created by Shawn on 2021/5/5.
//

import SwiftUI

let actors = ["亞歷山大·史柯斯嘉", "米莉·芭比·布朗", "蕾貝卡·霍爾","布萊恩·泰瑞·亨利", "小栗旬", "艾莎·岡薩雷", "朱利安·丹尼森", "凱爾·錢德勒", "德米安·畢齊", "凱莉·霍特爾"]
struct actor: View {
    
    var body: some View {
        NavigationView{
        VStack{
            Image("actor").resizable()
                .scaledToFit()
                .frame(width: 400, height: 250)
            ForEach(0..<actors.count){index in
                
                Text(actors[index])
            }
            
            
        }
        .navigationTitle("演員")
        }
    }
}

struct actor_Previews: PreviewProvider {
    static var previews: some View {
        actor()
    }
}
