//
//  Hello.swift
//  Damo
//
//  Created by Shawn on 2021/5/3.
//

import SwiftUI

struct move: View {
    var body: some View {
        NavigationView{
        VStack{
            Image("moveImg")
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 250)
            Text("《哥吉拉大戰金剛》（英語：Godzilla vs. Kong，中國大陸、香港譯《哥斯拉大戰金剛》，新加坡譯《哥吉拉大戰金剛》）是一部2021年美國科幻怪獸電影，由亞當·溫高德執導。該片為2017年電影《金剛：骷髏島》和2019電影《哥吉拉 II 怪獸之王》的續集，「怪獸宇宙」的第四部作品。主演包括亞歷山大·史柯斯嘉、米莉·芭比·布朗、蕾貝卡·霍爾、布萊恩·泰瑞·亨利、小栗旬、艾莎·岡薩雷、朱利安·丹尼森、凱爾·錢德勒和德米安·畢齊。")
        }
        .navigationTitle("介紹")
        }
    }
}

struct Hello_Previews: PreviewProvider {
    static var previews: some View {
        move()
    }
}
