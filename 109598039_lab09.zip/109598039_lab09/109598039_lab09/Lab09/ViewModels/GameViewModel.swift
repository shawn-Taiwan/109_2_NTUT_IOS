//
//  GameViewModel.swift
//  Lab09
//
//  Created by Shawn on 2021/5/19.
//

import Foundation

class GameViewModel: ObservableObject {
    @Published var playerIcon: Icon?
    @Published var computerIcon: Icon?
    @Published var result: GameResult?
    
    var icons: [Icon]{
        var icons = [Icon]()
        for hand in Icon.Hand.allCases{
            let icon = Icon(hand: hand)
            icons.append(icon)
        }
        return icons
    }
    
    func play() {
        var number = Int.random(in: 0...2)
        computerIcon=icons[number]
        number = Int.random(in: 0...2)
        playerIcon=icons[number]
        result = checkResul()
    }
    
    func checkResul() -> GameResult {
        let playerHand = Icon.Hand.allCases.firstIndex(of: playerIcon!.hand)
        let computerHand = Icon.Hand.allCases.firstIndex(of: computerIcon!.hand)
        if (playerHand! > computerHand!){
            if (playerHand! == 2 && computerHand! == 0){
                return .lose}
            return .win
        }else if(playerHand! == computerHand!){
            return .Tie
        }
        else{
            if (playerHand! == 0 && computerHand! == 2){
                return .win}
            return .lose
        }
    }
}
