enum GameResult{
    case win
    case lose
    case Tie
}
