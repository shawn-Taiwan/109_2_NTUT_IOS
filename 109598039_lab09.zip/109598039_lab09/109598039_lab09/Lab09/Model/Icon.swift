struct Icon {
    let hand: Hand
    
    enum Hand: String, CaseIterable{
        case paper = "🖐🏿 布"
        case scissor = "✌🏿 剪刀"
        case stone = "✊🏿 石頭"
    }
}
