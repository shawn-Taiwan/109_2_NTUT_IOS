//
//  Lab09App.swift
//  Lab09
//
//  Created by Shawn on 2021/5/19.
//

import SwiftUI

@main
struct Lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
