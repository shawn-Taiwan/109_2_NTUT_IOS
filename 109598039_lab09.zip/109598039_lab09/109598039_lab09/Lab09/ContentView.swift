//
//  ContentView.swift
//  Lab09
//
//  Created by Shawn on 2021/5/19.
//

import SwiftUI

struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    var body: some View {
        VStack{
            Text("猜拳遊戲").font(.system(size:100)).font(.title)
            Spacer()
            HStack{
                Text("玩家：").font(.system(size:50))
                Text(gameViewModel.playerIcon?.hand.rawValue ?? "").font(.system(size:50))
            }
            HStack{
                Text("電腦：").font(.system(size:50))
                Text(gameViewModel.computerIcon?.hand.rawValue ?? "").font(.system(size:50))
            }
            if let result = gameViewModel.result{
                if(result == .win){
                    Text("玩家獲勝").font(.system(size:50))
                }
                if(result == .lose){
                    Text("電腦獲勝").font(.system(size:50))
                }
                if(result == .Tie){
                    Text("平手").font(.system(size:50))
                }
            }
            VStack{
                Text("✌🏿").font(.system(size:50))
                HStack{
                    Text("✊🏿").font(.system(size:50))
                    Button(action: {gameViewModel.play()}, label: {
                        Text("出拳").font(.system(size:50))
                        })
                    Text("🖐🏿").font(.system(size:50))
                    }
                
                }
            }
        .padding(.top)
        .frame(
              minWidth: 0,
              maxWidth: .infinity,
              minHeight: 0,
              maxHeight: 600,
            alignment: .bottomTrailing
            )
        .background(Color.white)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
        }
    }
}
